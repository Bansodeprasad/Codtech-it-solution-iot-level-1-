# Smart-Car-Parking-System

This project is beneficial mostly for car parking areas in the public places, most of the places in the cities and public places
are facing a big issue regarding with the vehicle parking system. This project could be helpful to the various public places as 
the complete process gets automated through implementing various techniques and devices. 

The central controlling team will be having the governance to the whole unit through sensors and tracking devices. 
As being completely automated system it does not require any kind of human surveillance. The software system allows the
vehicles to allot the vacant parking slot and it displays all the occupied and vacant parking slots in the whole parking area.

The system handles entirely the allotment of parking slots by knowing the Occupied and vacant slots. Also, the system displays 
total parking slots, occupied parking slots and available parking slots along with the respective charges. The best part about
the system is that it automatically keeps track of the vehicles got entered into the parking slots and is able to auto generate 
the receipt with charges to the customer according to the time with respect to the charges.


Key features:

1. Customers get better option over the time consuming traditional parking system.
2. Improves traffic disciplines.
3. Quicker entrance and exit.
4. Reduced burden by keeping manual tracking and records.
5. Automatic charges receipt generation system.
6. Gets informed about vacant slots while entering the parking lot.
7. Helps to guide exact vacant slot in the multi storied buildings.
8. Improves safety by tracking vehicle and keeping records.
9. Enhance smart city idea.


Advantages:
1. There will be no need of a person for guidance to the vehicle parking lots, its arrangement and surveillance. 
Customers will come to know themselves about the parking slots.

2. There will be no need of a person for guidance to the vehicle parking lots, its arrangement and surveillance. 
Customers will come to know themselves about the parking slots.

3. There is central controlling system to handle and keep tracking on the proper working functionality of the system.

4. The customers can easily take entry in the parking lots without having trouble for finding the vacant slots and 
make exit by having payment receipt.

5. This system reduces human efforts and maintains discipline

- THANK YOU
